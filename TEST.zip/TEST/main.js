

$('.slidelist').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots:false,
    autoplay:true,
    arrow:true,
  
    
    });

  
//   let eb_slider = $('.slidelist')
//     eb_slider.slick({
//         arrows:false,
//         dots:false,
//         autoplay:true,
//         pauseOnHover:false,
//         fade:true,
//         infinite:true,
        
//     });
